"""在四张 GPU 上启动独立的 SGLang；前台监督，Ctrl+C 只停止本脚本的子进程。"""

from datetime import datetime
from importlib.metadata import version
import os
import shlex
import signal
import subprocess
import sys
import time
from urllib.request import build_opener, ProxyHandler

from settings import (SGLANG_VERSION, backend_urls, check_free_ports, common_parser,
                      load_config, process_lock, utc_now, write_json)


def gpu_tokens(config):
    # 若云平台已限制 CUDA_VISIBLE_DEVICES，编号相对于原来的可见卡列表。
    visible = os.environ.get("CUDA_VISIBLE_DEVICES")
    if visible is None:
        return [str(gpu) for gpu in config["gpu_ids"]]
    available = [token.strip() for token in visible.split(",") if token.strip()]
    if max(config["gpu_ids"]) >= len(available):
        raise RuntimeError("CUDA_VISIBLE_DEVICES 中没有配置要求的四张卡")
    return [available[gpu] for gpu in config["gpu_ids"]]


def backend_commands(config, python):
    return [[python, "-m", "sglang.launch_server", "--model-path", config["model_path"],
             "--host", "127.0.0.1", "--port", str(port), "--base-gpu-id", "0",
             *config["sglang_args"]] for port in config["backend_ports"]]


def stop_children(children):
    # 每个子进程有独立进程组，同时清理它产生的 SGLang 子进程。
    for child in children:
        try:
            os.killpg(child.pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
    deadline = time.monotonic() + 20
    while any(child.poll() is None for child in children) and time.monotonic() < deadline:
        time.sleep(0.2)
    for child in children:
        try:
            os.killpg(child.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        child.wait()


def main():
    parser = common_parser(__doc__)
    parser.add_argument("--dry-run", action="store_true", help="只显示命令，不导入 GPU 库或启动服务")
    args = parser.parse_args()
    config = load_config()
    commands, devices = backend_commands(config, sys.executable), gpu_tokens(config)
    for index, (command, device) in enumerate(zip(commands, devices)):
        print(f"backend {index}: CUDA_VISIBLE_DEVICES={device} {shlex.join(command)}", flush=True)
    if args.dry_run:
        return
    if sys.platform != "linux":
        parser.error("真实 SGLang 服务请在 Linux GPU 服务器运行；Mac 只使用 --dry-run")
    if version("sglang") != SGLANG_VERSION:
        raise RuntimeError(f"请安装 sglang=={SGLANG_VERSION}")
    import torch
    if not torch.cuda.is_available() or torch.cuda.device_count() <= max(config["gpu_ids"]):
        raise RuntimeError("PyTorch 没有发现配置要求的四张可用 GPU")

    args.runtime_dir = args.runtime_dir.resolve()
    with process_lock(args.runtime_dir, "backends"):
        check_free_ports(config["backend_ports"])
        log_dir = args.runtime_dir / "backends" / datetime.now().strftime("%Y%m%d-%H%M%S-%f")
        log_dir.mkdir(parents=True)
        stop_requested = False

        def stop_handler(signum, frame):
            nonlocal stop_requested
            stop_requested = True

        signal.signal(signal.SIGINT, stop_handler)
        signal.signal(signal.SIGTERM, stop_handler)
        children, logs = [], []
        manifest = {"status": "starting", "started_at": utc_now(), "config": config,
                    "torch_version": torch.__version__, "torch_cuda": torch.version.cuda,
                    "sglang_version": version("sglang"), "backends": []}
        opener = build_opener(ProxyHandler({}))
        try:
            for index, (command, device) in enumerate(zip(commands, devices)):
                env = dict(os.environ, CUDA_VISIBLE_DEVICES=device, PYTHONUNBUFFERED="1")
                env.setdefault("OMP_NUM_THREADS", "4")
                log_path = log_dir / f"backend-{index}.log"
                log = log_path.open("w")
                logs.append(log)
                child = subprocess.Popen(command, env=env, stdout=log, stderr=subprocess.STDOUT,
                                         start_new_session=True)
                children.append(child)
                manifest["backends"].append({"index": index, "url": backend_urls(config)[index],
                    "cuda_visible_devices": device, "pid": child.pid, "command": command,
                    "log": str(log_path)})
            write_json(log_dir / "launch.json", manifest)
            pending = set(range(4))
            deadline = time.monotonic() + config["startup_timeout_s"]
            while pending and not stop_requested:
                for index, child in enumerate(children):
                    if child.poll() is not None:
                        raise RuntimeError(f"backend {index} 提前退出，请查看 {log_dir}/backend-{index}.log")
                for index in list(pending):
                    try:
                        with opener.open(backend_urls(config)[index] + "/health", timeout=2) as response:
                            if response.status == 200:
                                pending.remove(index)
                                print(f"backend {index} 已就绪", flush=True)
                    except (OSError, TimeoutError):
                        pass
                if pending and time.monotonic() > deadline:
                    raise TimeoutError(f"后端启动超时：{sorted(pending)}；日志：{log_dir}")
                if pending:
                    time.sleep(1)
            if stop_requested:
                return
            manifest["status"] = "ready"
            write_json(log_dir / "launch.json", manifest)
            print(f"四个后端均已就绪。日志：{log_dir}。保持此终端运行。", flush=True)
            while not stop_requested:
                if any(child.poll() is not None for child in children):
                    raise RuntimeError(f"有后端退出，请查看 {log_dir}")
                time.sleep(1)
        finally:
            stop_children(children)
            for log in logs:
                log.close()
            manifest.update(status="stopped", stopped_at=utc_now())
            write_json(log_dir / "launch.json", manifest)


if __name__ == "__main__":
    main()
