"""共享配置与本地状态文件；不导入 Ray、PyTorch 或 SGLang。"""

import argparse
from copy import deepcopy
from contextlib import contextmanager
from datetime import datetime, timezone
import fcntl
import json
from pathlib import Path
import socket

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parents[1]

# 四个后端共用这些设置；如需调整，只改这里，并保持各对照组一致。
CONFIG = {'model_path': str(PROJECT / "models/Qwen3-0.6B"),
 'gpu_ids': [0, 1, 2, 3],
 'backend_ports': [31000, 31001, 31002, 31003],
 'serve_port': 8000,
 'head_cpus': 2,
 'worker_cpus': 2,
 'object_store_mb_per_node': 128,
 'startup_timeout_s': 900,
 'request_timeout_s': 300,
 'sglang_args': ['--dtype',
                 'bfloat16',
                 '--tp-size',
                 '1',
                 '--mem-fraction-static',
                 '0.75',
                 '--context-length',
                 '4096',
                 '--chunked-prefill-size',
                 '2048',
                 '--max-prefill-tokens',
                 '16384',
                 '--max-running-requests',
                 '128',
                 '--cuda-graph-max-bs-decode',
                 '32',
                 '--attention-backend',
                 'flashinfer',
                 '--stream-interval',
                 '1',
                 '--random-seed',
                 '2026']}

APP_NAME = "hw3"
WORKER_RESOURCE = "hw3_worker"
RAY_VERSION = "2.56.0"
SGLANG_VERSION = "0.5.14"
FORWARDED_HEADERS = ("X-Session-Id", "X-Workload-Request-ID", "X-Prefix-Family")


def common_parser(description):
    parser = argparse.ArgumentParser(description=description)
    parser.add_argument("--runtime-dir", type=Path, default=ROOT.parents[1] / "runtime")
    return parser


def load_config():
    config = deepcopy(CONFIG)
    ports, gpus = config["backend_ports"], config["gpu_ids"]
    if len(ports) != 4 or len(gpus) != 4 or len(set(gpus)) != 4:
        raise ValueError("需要四个后端端口和四个不同的 GPU 编号")
    if any(type(gpu) is not int or gpu < 0 for gpu in gpus):
        raise ValueError("gpu_ids 必须是非负整数")
    all_ports = ports + [config["serve_port"]]
    if len(set(all_ports)) != 5 or any(type(p) is not int or not 1024 <= p <= 65535 for p in all_ports):
        raise ValueError("后端和 Serve 必须使用五个不同的非特权端口")
    for key in ("head_cpus", "worker_cpus", "startup_timeout_s", "request_timeout_s"):
        if config[key] <= 0:
            raise ValueError(f"{key} 必须大于 0")
    if config["object_store_mb_per_node"] < 80:
        raise ValueError("每节点 object store 至少配置 80 MiB")
    if not config["model_path"] or not all(isinstance(x, str) for x in config["sglang_args"]):
        raise ValueError("检查 model_path 和 sglang_args")
    reserved = {"--host", "--port", "--model", "--model-path", "--base-gpu-id", "--disable-radix-cache"}
    if any(x.split("=", 1)[0] in reserved for x in config["sglang_args"]):
        raise ValueError("sglang_args 不可覆盖地址、模型、GPU 绑定或关闭 Radix Cache")
    return config


def backend_urls(config):
    return [f"http://127.0.0.1:{port}" for port in config["backend_ports"]]


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")
    temporary.replace(path)


@contextmanager
def process_lock(runtime_dir, name):
    """防止误启动同一组服务两次；只锁本项目，不影响其他进程。"""
    runtime_dir.mkdir(parents=True, exist_ok=True)
    with (runtime_dir / f"{name}.lock").open("w") as file:
        try:
            fcntl.flock(file, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise RuntimeError(f"{name} 已在运行，请先停止旧进程") from exc
        yield


def check_free_ports(ports):
    for port in ports:
        with socket.socket() as sock:
            try:
                sock.bind(("127.0.0.1", port))
            except OSError as exc:
                raise RuntimeError(f"端口 {port} 已被占用，请检查旧服务") from exc


def read_cluster(runtime_dir, config):
    state = json.loads((runtime_dir / "cluster.json").read_text())
    if state["status"] != "ready" or state["config"] != config:
        raise RuntimeError("集群未就绪或配置已变更，请重新启动 start_cluster.py")
    return state


def verify_nodes(nodes, state):
    alive = {node["NodeID"] for node in nodes if node["Alive"]}
    expected = {state["head_node_id"], *state["node_backends"]}
    if alive != expected or len(alive) != 5:
        raise RuntimeError(f"需要原来的 1 head + 4 workers；实际活跃节点：{alive}")


def require_ray_version(ray):
    if ray.__version__ != RAY_VERSION:
        raise RuntimeError(f"当前 Ray={ray.__version__}，本套代码按 {RAY_VERSION} 核对，请安装固定版本")
