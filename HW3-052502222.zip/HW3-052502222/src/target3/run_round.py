"""跑一轮：重新部署 → 保存配置 → 清缓存 → 课程预热和测量。"""

import json
import hashlib
from pathlib import Path
import shutil
import subprocess
import sys
from urllib.request import build_opener, ProxyHandler, Request

from settings import PROJECT, ROOT, backend_urls, common_parser, load_config, process_lock, write_json

COURSE = ROOT / "workload"


def main():
    parser = common_parser(__doc__)
    parser.add_argument("name", help="结果子目录，如 A_default/run-1")
    parser.add_argument("router", choices=("p2c", "consistent_hash", "affinity_load"))
    parser.add_argument("limit", type=int, help="每 Replica 的 max_ongoing_requests")
    parser.add_argument("--threshold", type=float, default=0.75, help="D 的亲和负载阈值")
    args = parser.parse_args()
    if args.limit <= 0 or not 0 < args.threshold <= 1:
        parser.error("并发上限须大于 0，D 阈值须在 (0, 1] 内")
    results = PROJECT / "results/target3"
    output = (results / args.name).resolve()
    if not output.is_relative_to(results.resolve()) or output == results.resolve():
        parser.error("name 必须是 results/target3 下的子目录")
    if output.exists():
        parser.error("结果目录已存在；重跑请换成 run-2 等新目录，不覆盖旧结果")
    config = load_config()
    runtime = args.runtime_dir.resolve()
    with process_lock(runtime, "round"):
        output.mkdir(parents=True)
        write_json(output / "source_sha256.json", {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(ROOT.iterdir()) if p.is_file()})
        try:
            # 同一组参数同时交给实际部署和课程回放，避免只改记录、没改路由。
            subprocess.run([sys.executable, str(ROOT / "deploy.py"),
                "--runtime-dir", str(runtime), "--router", args.router,
                "--max-ongoing-requests", str(args.limit),
                "--affinity-threshold", str(args.threshold)], check=True)
            for name in ("cluster.json", "deployment.json"):
                shutil.copy2(runtime / name, output / name)
            write_json(output / "backend-config.json", config)
            client = build_opener(ProxyHandler({}))
            for index, url in enumerate(backend_urls(config)):
                with client.open(url + "/server_info", timeout=30) as response:
                    write_json(output / f"backend-{index}.json", json.load(response))
            # 四次清缓存必须全部成功；之后直接回放，不再插入推理请求。
            flushed = []
            for url in backend_urls(config):
                with client.open(Request(url + "/flush_cache", method="POST"), timeout=30) as response:
                    if response.status != 200:
                        raise RuntimeError(f"清缓存失败：{url} HTTP {response.status}")
                    flushed.append({"backend": url, "status": response.status,
                                    "body": response.read().decode()})
            write_json(output / "flush.json", flushed)
            subprocess.run([sys.executable, str(COURSE / "run_workload.py"),
                "--policy", "serve", "--run-name", args.name, "--router-name", args.router,
                "--max-ongoing-requests", str(args.limit),
                "--base-url", f"http://127.0.0.1:{config['serve_port']}",
                "--model", config["model_path"], "--max-in-flight", "2048",
                "--timeout", str(config["request_timeout_s"]),
                "--workload", str(COURSE / "mooncake_prefix_workload_v2_seed2026.jsonl"),
                "--metadata", f"affinity_threshold={args.threshold}",
                "--output-dir", str(output)], check=True)
        except BaseException as exc:
            write_json(output / "round_error.json", {"error": f"{type(exc).__name__}: {exc}"})
            raise
    print(f"本轮完成，原始结果与配置：{output}")


if __name__ == "__main__":
    main()
