"""创建 1 head + 4 逻辑 worker；不启动 SGLang，也不部署 Serve。"""

import os
import signal
import tempfile
import time

from settings import (WORKER_RESOURCE, backend_urls, common_parser, load_config,
                      process_lock, require_ray_version, utc_now, verify_nodes, write_json)


def main():
    args = common_parser(__doc__).parse_args()
    config = load_config()
    args.runtime_dir = args.runtime_dir.resolve()
    # 在 Ray 子进程启动之前固定课程指定的 session header。
    os.environ["RAY_SERVE_SESSION_ID_HEADER_KEY"] = "x-session-id"
    import ray
    from ray.cluster_utils import Cluster
    require_ray_version(ray)

    with process_lock(args.runtime_dir, "cluster"):
        cluster = Cluster()
        stopped = False
        state = {"status": "starting", "pid": os.getpid(), "started_at": utc_now(), "config": config,
                 "ray_version": ray.__version__}
        write_json(args.runtime_dir / "cluster.json", state)

        def stop_handler(signum, frame):
            nonlocal stopped
            stopped = True

        signal.signal(signal.SIGINT, stop_handler)
        signal.signal(signal.SIGTERM, stop_handler)
        try:
            # 用短 ASCII 临时目录，避免 Ray Unix socket 的路径长度限制。
            ray_base = tempfile.mkdtemp(prefix="hw3-", dir="/tmp")
            os.environ["RAY_TMPDIR"] = ray_base
            ray_tmp = os.path.join(ray_base, "ray")
            common = {"num_gpus": 0,
                      "object_store_memory": config["object_store_mb_per_node"] * 1024 ** 2}
            cluster.add_node(num_cpus=config["head_cpus"], resources={"hw3_head": 1},
                             include_dashboard=False, temp_dir=ray_tmp, **common)
            for index in range(4):
                cluster.add_node(num_cpus=config["worker_cpus"],
                    resources={WORKER_RESOURCE: 1, f"hw3_backend_{index}": 1}, **common)
            cluster.wait_for_nodes(timeout=60)
            ray.init(address=cluster.address, namespace="hw3")
            alive = [node for node in ray.nodes() if node["Alive"]]
            head = [node for node in alive if node["Resources"].get("hw3_head") == 1]
            if len(alive) != 5 or len(head) != 1:
                raise RuntimeError("创建的节点数量不符合 1 head + 4 workers")
            mapping = {}
            for index, url in enumerate(backend_urls(config)):
                matched = [node for node in alive if node["Resources"].get(f"hw3_backend_{index}") == 1]
                if len(matched) != 1:
                    raise RuntimeError(f"worker {index} 标识不唯一")
                mapping[matched[0]["NodeID"]] = {"index": index, "url": url}
            state.update(status="ready", address=cluster.address, head_node_id=head[0]["NodeID"],
                         node_backends=mapping, ray_temp_dir=ray_tmp)
            verify_nodes(ray.nodes(), state)
            write_json(args.runtime_dir / "cluster.json", state)
            print(f"集群已就绪：{cluster.address}，1 head + 4 workers。保持此终端运行。", flush=True)
            while not stopped:
                verify_nodes(ray.nodes(), state)
                time.sleep(2)
        finally:
            if ray.is_initialized():
                ray.shutdown()
            cluster.shutdown()
            state.update(status="stopped", stopped_at=utc_now())
            write_json(args.runtime_dir / "cluster.json", state)


if __name__ == "__main__":
    main()
