"""每个 Ray Replica 固定绑定一个 SGLang，原样转发请求与 SSE。"""

import asyncio
import aiohttp
import ray
from ray import serve
from starlette.responses import JSONResponse, Response, StreamingResponse

from settings import FORWARDED_HEADERS


class ForwardedStream(StreamingResponse):
    """包括客户端断连、发送失败在内，均释放后端连接。"""

    def __init__(self, upstream, headers):
        self.upstream = upstream
        super().__init__(upstream.content.iter_any(), status_code=upstream.status, headers=headers)

    async def __call__(self, scope, receive, send):
        try:
            await super().__call__(scope, receive, send)
        finally:
            self.upstream.close()


class HTTPForwarder:
    def __init__(self, backend_url, identity, timeout_s):
        self.backend_url = backend_url
        self.identity = identity
        # 不额外限制连接数；每条请求使用新连接，避免复用后端已关闭的空闲连接。
        self.client = aiohttp.ClientSession(
            timeout=aiohttp.ClientTimeout(total=timeout_s, sock_connect=10),
            connector=aiohttp.TCPConnector(limit=0, force_close=True), auto_decompress=False, trust_env=False)

    async def close(self):
        await self.client.close()

    async def __call__(self, request):
        identity_headers = {
            "X-Ray-Replica-ID": self.identity["replica_id"],
            "X-Ray-Node-ID": self.identity["node_id"],
            "X-SGLang-Backend": self.backend_url,
        }
        if request.url.path == "/health" and request.method == "GET":
            return JSONResponse(self.identity, headers=identity_headers)
        if request.url.path != "/generate":
            return JSONResponse({"error": "仅支持 POST /generate 和 GET /health"}, status_code=404)
        if request.method != "POST":
            return Response(status_code=405, headers={"Allow": "POST"})
        headers = {name: request.headers[name] for name in FORWARDED_HEADERS if name in request.headers}
        headers["Content-Type"] = request.headers.get("content-type", "application/json")
        headers["Accept-Encoding"] = "identity"
        try:
            upstream = await self.client.post(self.backend_url + "/generate",
                data=await request.body(), headers=headers, allow_redirects=False)
        except (aiohttp.ClientError, asyncio.TimeoutError) as exc:
            return JSONResponse({"error": f"后端连接失败：{type(exc).__name__}"},
                                status_code=502, headers=identity_headers)
        try:
            response_headers = dict(identity_headers)
            for name in ("Content-Type", "Content-Encoding", "Cache-Control"):
                if name in upstream.headers:
                    response_headers[name] = upstream.headers[name]
            # 不转发 hop-by-hop 或 Content-Length；ASGI 负责 HTTP 传输分帧。
            # 保留原始响应状态和 SSE 字节，不解析、不重组、不等待完整输出。
            return ForwardedStream(upstream, response_headers)
        except BaseException:
            upstream.close()
            raise


@serve.deployment
class BackendForwarder:
    async def __init__(self, node_backends, timeout_s):
        node_id = ray.get_runtime_context().get_node_id()
        if node_id not in node_backends:
            raise RuntimeError("Replica 被放到了未登记的节点（不能放在 head 上）")
        backend = node_backends[node_id]
        context = serve.get_replica_context()
        identity = {"replica_id": context.replica_id.to_full_id_str(),
                    "node_id": node_id, "backend": backend["url"], "backend_index": backend["index"]}
        self.forwarder = HTTPForwarder(backend["url"], identity, timeout_s)

    async def __call__(self, request):
        return await self.forwarder(request)

    async def __del__(self):
        if hasattr(self, "forwarder"):
            await self.forwarder.close()
