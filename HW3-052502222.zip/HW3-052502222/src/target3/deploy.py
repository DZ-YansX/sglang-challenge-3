"""重新部署四副本：A/B 用 P2C，C 用严格一致性哈希，D 用亲和加负载路由。"""

import math

from settings import (APP_NAME, ROOT, WORKER_RESOURCE, common_parser, load_config,
                      process_lock, read_cluster, require_ray_version, utc_now, verify_nodes, write_json)


def router_settings(router, affinity_threshold=0.75):
    """返回可记录的类路径和参数；P2C 保留 Ray 默认路由器。"""
    if router == "p2c":
        return None, {}
    if router == "consistent_hash":
        return ("ray.serve.experimental.consistent_hash_router:ConsistentHashRouter",
                {"num_virtual_nodes": 100, "num_fallback_replicas": 0})
    if router == "affinity_load":
        return ("improved_router:AffinityLoadRouter",
                {"num_virtual_nodes": 100, "affinity_threshold": affinity_threshold})
    raise ValueError(f"未知路由器：{router}")


def main():
    parser = common_parser(__doc__)
    parser.add_argument("--router", choices=("p2c", "consistent_hash", "affinity_load"), default="p2c")
    parser.add_argument("--max-ongoing-requests", type=int, default=5)
    parser.add_argument("--affinity-threshold", type=float, default=0.75,
                        help="D 的亲和副本 ongoing/max_ongoing 阈值，范围 (0, 1]，默认 0.75")
    parser.add_argument("--stop", action="store_true", help="停止本作业专用集群中的 Serve，保留 Ray 和 SGLang")
    args = parser.parse_args()
    if args.max_ongoing_requests <= 0:
        parser.error("--max-ongoing-requests 必须大于 0")
    if not math.isfinite(args.affinity_threshold) or not 0 < args.affinity_threshold <= 1:
        parser.error("--affinity-threshold 必须在 (0, 1] 范围内")
    router_class, router_kwargs = router_settings(args.router, args.affinity_threshold)
    config = load_config()
    args.runtime_dir = args.runtime_dir.resolve()
    state = read_cluster(args.runtime_dir, config)
    import ray
    from ray import serve
    from ray.serve.config import RequestRouterConfig
    from serve_app import BackendForwarder
    require_ray_version(ray)
    with process_lock(args.runtime_dir, "deploy"):
        ray.init(address=state["address"], namespace="hw3", runtime_env={
            "env_vars": {"PYTHONPATH": str(ROOT), "RAY_SERVE_SESSION_ID_HEADER_KEY": "x-session-id"}})
        try:
            verify_nodes(ray.nodes(), state)
            # 本脚本连接的是 start_cluster.py 创建的作业专用集群。
            # 只 delete 同名应用时，Proxy 可能复用旧 handle/router；切换 P2C→C
            # 已在本地复现。因此每轮重建整个 Serve（不重启 Ray 节点或 SGLang）。
            serve.shutdown()
            write_json(args.runtime_dir / "deployment.json", {"status": "stopped", "at": utc_now()})
            if args.stop:
                print("已停止本作业的 Serve；Ray 集群和 SGLang 后端仍运行。")
                return
            # 只有 head 提供 HTTP 入口，所有组共用同一个地址。
            serve.start(proxy_location="HeadOnly", http_options={
                "host": "127.0.0.1", "port": config["serve_port"],
                "request_timeout_s": config["request_timeout_s"]})
            options = dict(num_replicas=4, max_replicas_per_node=1,
                           max_ongoing_requests=args.max_ongoing_requests,
                           max_queued_requests=-1,
                           ray_actor_options={"num_cpus": 1, "num_gpus": 0,
                                              "resources": {WORKER_RESOURCE: 1}})
            if router_class is not None:
                options["request_router_config"] = RequestRouterConfig(
                    request_router_class=router_class, request_router_kwargs=router_kwargs)
            # P2C 不替换路由器，保留 Ray 默认实现。
            app = BackendForwarder.options(**options).bind(state["node_backends"], config["request_timeout_s"])
            serve.run(app, name=APP_NAME, route_prefix="/")
            deployment = {"status": "ready", "at": utc_now(), "router": args.router,
                "router_class": router_class, "router_kwargs": router_kwargs,
                "max_ongoing_requests": args.max_ongoing_requests, "ray_version": ray.__version__,
                "config": config, "head_node_id": state["head_node_id"],
                "node_backends": state["node_backends"], "url": f"http://127.0.0.1:{config['serve_port']}"}
            write_json(args.runtime_dir / "deployment.json", deployment)
            print(f"部署完成：{deployment['url']}，router={args.router}，max_ongoing_requests={args.max_ongoing_requests}")
            print("部署就绪。正式回放前必须清空四个后端缓存。")
        finally:
            ray.shutdown()


if __name__ == "__main__":
    main()
