"""D：普通前缀保持亲和，只为持续占用容量的热前缀逐步增加副本。

负载由 Ray 2.56.0 的请求接受/完成回调维护，只使用已到达的排队请求及当前未完成请求。
不读 workload，不预知热度或输出长度，也不在 choose_replicas 中额外发 RPC。
"""

import asyncio
from collections import Counter
import math

from ray.serve.experimental.consistent_hash_router import ConsistentHashRouter


class AffinityLoadRouter(ConsistentHashRouter):
    """按需扩展前缀的承载集合；保留 Ray 原生背压和重试。"""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._affinity_threshold = 0.75
        self._family_owners = {}
        self._family_ongoing = Counter()
        self._family_demand = Counter()
        self._tracked_requests = {}
        self._replica_ongoing = Counter()
        self._accepted_requests = {}
        self._reservations = {}
        self._replica_reserved = Counter()
        self._capacity_changed = asyncio.Event()

    def initialize_state(self, **kwargs):
        threshold = kwargs.get("affinity_threshold", 0.75)
        if (isinstance(threshold, bool) or not isinstance(threshold, (int, float))
                or not math.isfinite(threshold) or not 0 < threshold <= 1):
            raise ValueError("affinity_threshold 必须是 (0, 1] 内的有限数值")
        self._affinity_threshold = float(threshold)
        super().initialize_state(
            num_virtual_nodes=kwargs.get("num_virtual_nodes", 100),
            num_fallback_replicas=3,
        )

    def _track_request(self, pending_request):
        request_id = pending_request.metadata.internal_request_id
        if request_id not in self._tracked_requests:
            family = self._routing_key(pending_request)
            self._tracked_requests[request_id] = family
            self._family_demand[family] += 1

    def _forget_request(self, request_id):
        family = self._tracked_requests.pop(request_id, None)
        if family is not None:
            self._family_demand[family] -= 1
            if self._family_demand[family] == 0:
                del self._family_demand[family]

    async def _choose_replica_for_request(self, pending_request, *, is_retry=False):
        # 在入队时计数，包含已经到达但还未轮到 choose_replicas 的请求。
        # Ray 2.56.0 的重试复用请求 ID，不能重复计数。
        self._track_request(pending_request)
        try:
            return await super()._choose_replica_for_request(
                pending_request, is_retry=is_retry)
        except BaseException:
            request_id = pending_request.metadata.internal_request_id
            self._forget_request(request_id)
            self._release_reservation(request_id)
            self._capacity_changed.set()
            raise

    def _load(self, replica_id):
        return self._replica_ongoing[replica_id] + self._replica_reserved[replica_id]

    def _release_reservation(self, request_id):
        replica_id = self._reservations.pop(request_id, None)
        if replica_id is not None:
            self._replica_reserved[replica_id] -= 1
            if self._replica_reserved[replica_id] == 0:
                del self._replica_reserved[replica_id]

    async def _select_from_candidate_replicas(self, candidates, backoff_index):
        # 本作业只有一个 Head HTTP Proxy，所有请求都经过这个路由器。
        # 直接使用生命周期账本，避免每个等待请求重复 RPC 探测。
        available = [r for r in candidates if r.replica_id in self._replicas
                     and self._load(r.replica_id) < r.max_ongoing_requests]
        return min(available, key=lambda r: self._load(r.replica_id)
                   / r.max_ongoing_requests, default=None)

    def _fulfill_next_pending_request(self, replica, request_metadata=None):
        pending = self._get_pending_request_matching_internal_request_id(request_metadata)
        super()._fulfill_next_pending_request(replica, request_metadata)
        if pending is not None and pending.future.done() and not pending.future.cancelled():
            request_id = pending.metadata.internal_request_id
            if request_id not in self._reservations:
                self._reservations[request_id] = replica.replica_id
                self._replica_reserved[replica.replica_id] += 1

    async def _backoff(self, attempt):
        self._capacity_changed.clear()
        try:
            await asyncio.wait_for(self._capacity_changed.wait(),
                                   timeout=self._compute_backoff_s(attempt))
        except asyncio.TimeoutError:
            pass

    def on_request_routed(self, pending_request, replica_id, result):
        self._track_request(pending_request)
        request_id = pending_request.metadata.internal_request_id
        self._release_reservation(request_id)
        if request_id not in self._accepted_requests:
            family = self._routing_key(pending_request)
            self._accepted_requests[request_id] = (family, replica_id)
            self._family_ongoing[family] += 1
            self._replica_ongoing[replica_id] += 1

    def on_request_completed(self, replica_id, internal_request_id):
        accepted = self._accepted_requests.get(internal_request_id)
        # 被拒绝、重复完成通知或旧副本的通知都不重复扣减。
        if accepted is not None and accepted[1] != replica_id:
            return
        reserved = self._reservations.get(internal_request_id)
        if reserved is not None and reserved != replica_id:
            return
        self._forget_request(internal_request_id)
        self._release_reservation(internal_request_id)
        self._capacity_changed.set()
        if accepted is None:
            return
        family, replica_id = self._accepted_requests.pop(internal_request_id)
        self._family_ongoing[family] -= 1
        self._replica_ongoing[replica_id] -= 1
        if self._family_ongoing[family] == 0:
            del self._family_ongoing[family]
        if self._replica_ongoing[replica_id] == 0:
            del self._replica_ongoing[replica_id]

    async def choose_replicas(self, candidate_replicas, pending_request=None):
        candidates = {r.replica_id: r for r in candidate_replicas
                      if r.replica_id in self._replicas}
        if not candidates:
            return []
        if pending_request is not None:
            pending_request.routing_context.should_backoff = True
        family = self._routing_key(pending_request)
        if family is None:
            return [list(candidates.values())]

        ranked = [r for r in self._lookup_ranked_replicas(family) if r in candidates]
        if not ranked:
            return [list(candidates.values())]
        owners = [r for r in self._family_owners.get(family, [ranked[0]])
                  if r in candidates]
        if not owners:
            owners = [ranked[0]]

        # 排队也算需求：只有已到达的本族需求足够大，且现有承载副本
        # 繁忙，才逐步扩展。已接纳数量不足不代表没有大量请求在等候。
        soft_capacity = sum(max(1, math.ceil(candidates[r].max_ongoing_requests
                            * self._affinity_threshold)) for r in owners)
        owners_busy = all(self._load(r) >= max(1, math.ceil(
            candidates[r].max_ongoing_requests * self._affinity_threshold))
            for r in owners)
        alternatives = [r for r in ranked if r not in owners]
        if alternatives and owners_busy:
            extra = min(alternatives, key=lambda r: self._load(r)
                        / candidates[r].max_ongoing_requests)
            owners_full = all(self._load(r) >=
                              candidates[r].max_ongoing_requests for r in owners)
            spare = (self._load(extra) / candidates[extra].max_ongoing_requests
                     < 1 - self._affinity_threshold)
            # 小前缀仅在原承载集合已满、另有明显空闲副本时逃离阻塞。
            if self._family_demand[family] >= soft_capacity or (owners_full and spare):
                owners.append(extra)
        self._family_owners[family] = owners

        # 已扩展的集合保持稳定，以复用先前计算的前缀；在集合内选择
        # 有容量的副本。Serve Replica 仍执行原生 max_ongoing_requests 拒绝检查。
        return [[candidates[r] for r in owners]]
