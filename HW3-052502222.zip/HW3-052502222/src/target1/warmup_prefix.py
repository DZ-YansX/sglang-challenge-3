"""只发送一条共享前缀预热请求；不清缓存，不发送 32 条测量请求。"""
from common import arguments, dataset, folder_for, client, checked_server, require_state, save_state, generate, request_body, write_json, entrypoint


async def main():
    args = arguments(__doc__)
    args.group = 'shared_prefix'
    _, ids, digest = dataset(args)
    require_state(args, 'flushed', digest)
    out = folder_for(args)
    save_state(args, 'prefix_warmup_started', digest)
    async with client() as session:
        await checked_server(session, args.url)
        row = await generate(session, args.url, request_body(ids), 'prefix-warmup', len(ids))
    write_json(out / 'prefix_warmup.json', {'input_ids': ids, 'result': row})
    if row['status'] != 'ok':
        raise RuntimeError(row['error'])
    save_state(args, 'prefix_warmed', digest)
    print('共享前缀预热完成，仅发送了 1 条请求，不计入正式测量。')
    print('接下来运行 run_group.py --group shared_prefix；此时不要再清缓存。')


if __name__ == '__main__':
    entrypoint(main)
