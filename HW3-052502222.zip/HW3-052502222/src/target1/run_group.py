"""只测量 --group 指定的一组 32 条请求；不清缓存、不预热、不汇总。"""
import asyncio
import csv
import time
from common import arguments, dataset, folder_for, client, checked_server, require_state, save_state, request_body, generate, write_json, write_jsonl, N, CONCURRENCY, INPUT_LEN, PARAMS, entrypoint


async def main():
    args = arguments(__doc__, group=True)
    groups, _, digest = dataset(args)
    require_state(args, 'prefix_warmed' if args.group == 'shared_prefix' else 'flushed', digest)
    out = folder_for(args)
    if (out / 'requests.jsonl').exists() or (out / 'measurement.json').exists():
        raise RuntimeError('测量文件已存在；请使用新的 --run-name 并重新准备缓存')
    inputs = groups[args.group]
    bodies = [request_body(row['input_ids']) for row in inputs]
    write_jsonl(out / 'inputs.jsonl', inputs)
    sem = asyncio.Semaphore(CONCURRENCY)
    async with client() as session:
        info = await checked_server(session, args.url)
        write_json(out / 'server_info.json', info)
        save_state(args, 'measuring', digest)
        async def one(i):
            async with sem:
                return await generate(session, args.url, bodies[i], i, INPUT_LEN)
        print(f'开始测量 {args.group}: 32 条请求，最大并发 8。', flush=True)
        started = time.perf_counter()
        rows = await asyncio.gather(*(one(i) for i in range(N)))
        duration = time.perf_counter() - started
    write_jsonl(out / 'requests.jsonl', rows)
    fields = sorted(set().union(*(row.keys() for row in rows)) - {'events', 'final_meta_info'})
    with (out / 'requests.csv').open('w', newline='', encoding='utf-8-sig') as f:
        writer = csv.DictWriter(f, fieldnames=fields, extrasaction='ignore')
        writer.writeheader()
        writer.writerows(rows)
    write_json(out / 'measurement.json', {
        'group': args.group, 'run_name': args.run_name, 'url': args.url,
        'measurement_wall_s': duration, 'data_sha256': digest,
        'sampling_params': PARAMS, 'max_concurrency': CONCURRENCY,
        'timing': 'TTFT=first-token-send; E2E=last-token-send; TPOT=(E2E-TTFT)/15. Client semaphore wait excluded; wall time includes stream closure.'})
    good = sum(row['status'] == 'ok' for row in rows)
    save_state(args, 'measured' if good == N else 'measurement_failed', digest)
    print(f'本组结束：{good}/32 有效，原始结果保存在 {out}。没有自动运行下一组或汇总。')
    if good != N:
        for row in rows:
            if row['status'] != 'ok':
                print(row['request_id'], row['error'])
        raise RuntimeError('本组存在失败或无效请求；排查后用新 run-name 重做')


if __name__ == '__main__':
    entrypoint(main)
