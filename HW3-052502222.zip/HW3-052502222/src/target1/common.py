"""共享的 HTTP、文件读写和参数函数；导入时不会发送请求。"""
import argparse
import asyncio
import json
import sys
import time
import hashlib
from datetime import datetime, timezone
from pathlib import Path
import aiohttp

PARAMS = dict(temperature=0, max_new_tokens=16, ignore_eos=True,
              sampling_seed=2026, stream_interval=1)
N, CONCURRENCY, INPUT_LEN, PREFIX_LEN = 32, 8, 2112, 2048
GROUPS = ("shared_prefix", "dispersed_prefix")


def entrypoint(fn):
    try:
        result = fn()
        if asyncio.iscoroutine(result):
            asyncio.run(result)
    except KeyboardInterrupt:
        sys.exit('已中断。重新测量前等待服务器空闲，并重新清缓存、预热。')
    except Exception as exc:
        sys.exit(f'ERROR: {type(exc).__name__}: {exc}')


def arguments(description, group=False):
    parser = argparse.ArgumentParser(description=description)
    parser.add_argument('--url', default='http://127.0.0.1:30000')
    parser.add_argument('--data', default=str(Path(__file__).resolve().parent / 'data'))
    parser.add_argument('--out', default='results/target1')
    parser.add_argument('--run-name', default='run-1')
    if group:
        parser.add_argument('--group', required=True, choices=GROUPS)
    args = parser.parse_args()
    args.url = args.url.rstrip('/')
    if Path(args.run_name).name != args.run_name or args.run_name in ('.', '..'):
        parser.error('--run-name 必须是单个目录名')
    return args


def client():
    return aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=600, sock_read=180),
                                 connector=aiohttp.TCPConnector(limit=CONCURRENCY))


def load_json(path):
    return Path(path).read_text(encoding='utf-8')


def read_json(path):
    return json.loads(load_json(path))


def read_jsonl(path):
    return [json.loads(line) for line in load_json(path).splitlines() if line.strip()]


def folder_for(args, group=None):
    return Path(args.out) / (group or args.group) / args.run_name


def dataset(args):
    root = Path(args.data)
    groups = {name: read_jsonl(root / (name + '.jsonl')) for name in GROUPS}
    for name, rows in groups.items():
        if len(rows) != N or [r['request_id'] for r in rows] != list(range(N)):
            raise ValueError(f'{name} 必须包含按 0..31 排序的 32 条请求')
        if any(len(r['input_ids']) != INPUT_LEN or
               any(type(x) is not int or x < 0 for x in r['input_ids']) for r in rows):
            raise ValueError(f'{name} 输入必须为 2112 个非负整数 ID')
    shared = [r['input_ids'] for r in groups['shared_prefix']]
    dispersed = [r['input_ids'] for r in groups['dispersed_prefix']]
    warm = read_json(root / 'prefix_warmup.json')['input_ids']
    if not all(x[:PREFIX_LEN] == shared[0][:PREFIX_LEN] for x in shared):
        raise ValueError('共享组前 2048 token 不一致')
    if len({x[0] for x in dispersed}) != N:
        raise ValueError('分散组首 token 不满足各不相同')
    if any(a[1:] != b[1:] or a[0] == b[0] for a, b in zip(shared, dispersed)):
        raise ValueError('本实验设计要求配对输入只在首 token 处不同')
    if len(warm) != INPUT_LEN or warm[:PREFIX_LEN] != shared[0][:PREFIX_LEN]:
        raise ValueError('预热输入的长度或共享前缀错误')
    if len({x[PREFIX_LEN] for x in shared + [warm]}) != N + 1:
        raise ValueError('测量与预热后缀的首 token 必须互不相同')
    digest = hashlib.sha256(json.dumps([groups, warm], sort_keys=True).encode()).hexdigest()
    return groups, warm, digest


async def checked_server(session, url):
    info = await get_json(session, url + '/get_server_info')
    config = info.get('server_args', info)
    if str(info.get('version', '')).split('+')[0] != '0.5.14':
        raise ValueError(f"题目要求 0.5.14，实际服务版本为 {info.get('version')}")
    if config.get('disable_radix_cache') is not False:
        raise ValueError('disable_radix_cache 不是 False 或字段缺失，不能确认前缀缓存开启')
    if config.get('speculative_algorithm'):
        raise ValueError('请关闭推测解码，以便进行本实验的逐 token 测量')
    return info


def save_state(args, stage, digest=None):
    root = Path(args.out)
    root.mkdir(parents=True, exist_ok=True)
    write_json(root / 'preparation_state.json', {
        'stage': stage, 'group': getattr(args, 'group', None), 'run_name': args.run_name,
        'url': args.url, 'data_sha256': digest, 'time_utc': datetime.now(timezone.utc).isoformat()})


def require_state(args, stage, digest):
    state = read_json(Path(args.out) / 'preparation_state.json')
    for key, expected in [('stage', stage), ('group', args.group), ('run_name', args.run_name),
                          ('url', args.url), ('data_sha256', digest)]:
        if state.get(key) != expected:
            raise ValueError(f'准备步骤不匹配 ({key})；请按 README 重新清缓存和必要的前缀预热')
    # This file guards this client's operation order, not external requests or
    # a server restart. Run commands sequentially against an exclusive server.
    return state


def write_json(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

def write_jsonl(path, data):
    path.write_text("".join(json.dumps(x, ensure_ascii=False) + "\n" for x in data), encoding="utf-8")

def request_body(ids):
    return json.dumps({"input_ids": ids, "sampling_params": PARAMS,
                       "stream": True}).encode("utf-8")

async def generate(session, url, body, request_id, expected_input):
    row = {"request_id": request_id, "status": "error", "http_status": None,
           "prompt_tokens": None, "completion_tokens": None, "cached_tokens": None,
           "prefill_tokens": None, "ttft_ms": None, "tpot_ms": None,
           "e2e_ms": None, "first_chunk_tokens": None, "total_retractions": None,
           "error": None, "events": []}
    first, last, previous_count, final_meta, done = None, None, 0, {}, False
    start = time.perf_counter()
    row["sent_at_utc"] = datetime.now(timezone.utc).isoformat()
    row["start_perf_s"] = start
    try:
        async with session.post(url + "/generate", data=body,
                                headers={"Content-Type": "application/json"}) as response:
            row["http_status"] = response.status
            if response.status != 200:
                raise RuntimeError(f"HTTP {response.status}: {(await response.text())[:1500]}")
            # aiohttp's content iterator yields complete lines, not arbitrary
            # TCP chunks. Native SGLang emits one JSON object per SSE data line.
            async for raw in response.content:
                now = time.perf_counter()
                line = raw.decode("utf-8").strip()
                if not line or line.startswith(":"):
                    continue
                if not line.startswith("data:"):
                    raise RuntimeError(f"Unexpected SSE line: {line[:200]}")
                payload = line[5:].strip()
                if payload == "[DONE]":
                    done = True
                    break
                event = json.loads(payload)
                row["events"].append({"elapsed_ms": (now - start) * 1000, "data": event})
                if "error" in event:
                    raise RuntimeError(str(event["error"]))
                meta = event.get("meta_info") or {}
                final_meta.update(meta)
                count = meta.get("completion_tokens", previous_count)
                if count < previous_count:
                    raise RuntimeError("completion_tokens decreased unexpectedly")
                if count > previous_count:
                    if first is None:
                        first = now
                        row["first_chunk_tokens"] = count
                    last = now
                    previous_count = count
            row["stream_end_ms"] = (time.perf_counter() - start) * 1000
        for key in ("prompt_tokens", "completion_tokens", "cached_tokens"):
            if key not in final_meta:
                raise RuntimeError(f"Missing meta_info.{key}; do not replace missing cache data with zero")
            row[key] = final_meta[key]
        row["final_meta_info"] = final_meta
        row["total_retractions"] = final_meta.get("total_retractions")
        if first is not None and last is not None:
            row["ttft_ms"] = (first - start) * 1000
            # E2E is client send -> receipt of the last generated token.
            # SSE closing-marker overhead is separately saved as stream_end_ms.
            row["e2e_ms"] = (last - start) * 1000
            row["tpot_ms"] = (last - first) * 1000 / (row["completion_tokens"] - 1) if row["completion_tokens"] > 1 else None
        row["prefill_tokens"] = row["prompt_tokens"] - row["cached_tokens"]
        if not done:
            raise RuntimeError("SSE stream ended without [DONE]")
        if row["prompt_tokens"] != expected_input or row["completion_tokens"] != 16:
            raise RuntimeError(f"Token length mismatch: input={row['prompt_tokens']}, output={row['completion_tokens']}")
        if not 0 <= row["cached_tokens"] <= row["prompt_tokens"]:
            raise RuntimeError("Invalid cached_tokens count")
        if row["first_chunk_tokens"] != 1:
            raise RuntimeError("First chunk did not contain exactly one token; TTFT cannot be measured accurately. Use --stream-interval 1 and disable speculative decoding.")
        finish = final_meta.get("finish_reason")
        if not isinstance(finish, dict) or finish.get("type") != "length":
            raise RuntimeError(f"Unexpected finish_reason: {finish}")
        row["status"] = "ok"
    except Exception as exc:
        row["error"] = f"{type(exc).__name__}: {exc}"
    row["finished_perf_s"] = time.perf_counter()
    return row

async def get_json(session, url):
    async with session.get(url) as response:
        response.raise_for_status()
        return await response.json()

async def flush(session, url):
    async with session.post(url + "/flush_cache", params={"timeout": 30}) as response:
        text = await response.text()
        record = {"http_status": response.status, "response": text,
                  "time_utc": datetime.now(timezone.utc).isoformat()}
        if response.status != 200 or "Cache flushed" not in text:
            raise RuntimeError(f"Cache flush failed; stop other clients before running: {record}")
        return record
