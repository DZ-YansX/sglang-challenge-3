"""只发送一条短请求预热服务，不进行前缀组预热或正式测量。"""
from pathlib import Path
from common import arguments, client, checked_server, read_json, generate, request_body, write_json, save_state, entrypoint


async def main():
    args = arguments(__doc__)
    ids = read_json(Path(args.data) / 'service_warmup.json')['input_ids']
    out = Path(args.out) / args.run_name
    out.mkdir(parents=True, exist_ok=True)
    save_state(args, 'service_warmup_started')
    async with client() as session:
        await checked_server(session, args.url)
        row = await generate(session, args.url, request_body(ids), 'service-warmup', len(ids))
    write_json(out / 'service_warmup.json', row)
    if row['status'] != 'ok':
        raise RuntimeError(row['error'])
    save_state(args, 'service_warmed')
    print(f"短请求预热完成：输入 {len(ids)} token，输出 {row['completion_tokens']} token。未进行正式测量。")


if __name__ == '__main__':
    entrypoint(main)
