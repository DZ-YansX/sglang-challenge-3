"""离线统计函数，不发送 HTTP 请求。"""
import math

def percentile(values, q):
    if not values:
        return None
    values = sorted(values)
    index = (len(values) - 1) * q
    lo, hi = math.floor(index), math.ceil(index)
    return values[lo] + (values[hi] - values[lo]) * (index - lo)

def summarize(name, rows, duration):
    good = [r for r in rows if r["status"] == "ok"]
    inp = sum(r["prompt_tokens"] for r in good)
    cache = sum(r["cached_tokens"] for r in good)
    out = sum(r["completion_tokens"] for r in good)
    result = {"group": name, "requests": len(rows), "successful": len(good),
              "success_rate": len(good) / len(rows), "measurement_wall_s": duration,
              "request_throughput_rps": len(good) / duration,
              "output_throughput_tokens_s": out / duration,
              "total_throughput_tokens_s": (inp + out) / duration,
              "prompt_tokens_sum": inp, "completion_tokens_sum": out,
              "cached_tokens_sum": cache, "cache_hit_rate": cache / inp if inp else None,
              "prefill_tokens_sum": inp - cache,
              "nonzero_retractions": sum((r["total_retractions"] or 0) > 0 for r in good)}
    for metric in ("ttft_ms", "tpot_ms", "e2e_ms"):
        values = [r[metric] for r in good if r[metric] is not None]
        for label, q in (("p50", .5), ("p95", .95)):
            result[f"{metric}_{label}"] = percentile(values, q)
    return result

def comparison(summaries):
    by_name = {s["group"]: s for s in summaries}
    order = [by_name[x] for x in ("shared_prefix", "dispersed_prefix")]
    metrics = [("成功率", "success_rate"), ("请求吞吐量 (req/s)", "request_throughput_rps"),
               ("输出吞吐量 (token/s)", "output_throughput_tokens_s"),
               ("输入+输出吞吐量 (token/s)", "total_throughput_tokens_s"),
               ("缓存命中率", "cache_hit_rate"), ("输入 token 总数", "prompt_tokens_sum"),
               ("输出 token 总数", "completion_tokens_sum"), ("缓存 token 总数", "cached_tokens_sum"),
               ("实际 Prefill token 总数", "prefill_tokens_sum")]
    for metric, label in (("ttft", "TTFT"), ("tpot", "TPOT"), ("e2e", "端到端延迟")):
        for p in ("p50", "p95"):
            metrics.append((f"{label} {p} (ms)", f"{metric}_ms_{p}"))
    lines = ["| 指标 | 共享前缀 | 分散前缀 |", "|---|---:|---:|"]
    for label, key in metrics:
        values = []
        for s in order:
            value = s[key]
            values.append("缺失" if value is None else
                          f"{value:.2%}" if key in ("success_rate", "cache_hit_rate") else
                          str(value) if isinstance(value, int) else f"{value:.3f}")
        lines.append(f"| {label} | {values[0]} | {values[1]} |")
    return "\n".join(lines) + "\n"
