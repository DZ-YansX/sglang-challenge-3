"""只读取已有结果并生成统计表；服务器可以关闭，不会发送请求。"""
import argparse
import csv
from pathlib import Path
from common import GROUPS, read_json, read_jsonl, write_json, entrypoint
from metrics import summarize, comparison


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', default='results/target1')
    parser.add_argument('--run-name', default='run-1')
    args = parser.parse_args()
    if Path(args.run_name).name != args.run_name or args.run_name in ('.', '..'):
        parser.error('--run-name 必须是单个目录名')
    root = Path(args.out)
    summaries, measurements, configs, records = [], [], [], []
    for group in GROUPS:
        folder = root / group / args.run_name
        rows = read_jsonl(folder / 'requests.jsonl')
        meta = read_json(folder / 'measurement.json')
        if len(rows) != 32 or [r['request_id'] for r in rows] != list(range(32)):
            raise RuntimeError(f'{group} 逐请求记录数量/顺序不正确')
        if meta['group'] != group or meta['run_name'] != args.run_name:
            raise RuntimeError('测量元数据与目录不匹配')
        result = summarize(group, rows, meta['measurement_wall_s'])
        measurements.append(meta)
        summaries.append(result)
        records.append(rows)
        info = read_json(folder / 'server_info.json')
        config = info.get('server_args', info)
        # Exclude dynamic runtime counters, compare actual experimental settings.
        keys = ['model_path','tokenizer_path','dtype','kv_cache_dtype','attention_backend',
                'tp_size','dp_size','pp_size','context_length','mem_fraction_static',
                'chunked_prefill_size','max_running_requests','max_total_tokens','page_size',
                'schedule_policy','disable_radix_cache','disable_overlap_schedule',
                'enable_deterministic_inference','speculative_algorithm','stream_interval',
                'quantization','cuda_graph_config','random_seed','model_impl']
        configs.append({'version': info.get('version'), **{k: config.get(k) for k in keys}})
    for key in ('data_sha256', 'sampling_params', 'max_concurrency', 'url'):
        if measurements[0][key] != measurements[1][key]:
            raise RuntimeError(f'两组配置不一致：{key}')
    if configs[0] != configs[1]:
        raise RuntimeError('两组服务器实验配置不一致，不能直接比较')
    valid_rows = all(row['status'] == 'ok' and row['prompt_tokens'] == 2112 and
                     row['completion_tokens'] == 16 for rows in records for row in rows)
    shared, dispersed = summaries
    passed = (valid_rows and shared['cache_hit_rate'] is not None and
              dispersed['cache_hit_rate'] is not None and
              shared['cache_hit_rate'] > dispersed['cache_hit_rate'] and
              shared['prefill_tokens_sum'] < dispersed['prefill_tokens_sum'])
    for group, summary in zip(GROUPS, summaries):
        write_json(root / group / args.run_name / 'summary.json', summary)
    dest = root / args.run_name
    dest.mkdir(parents=True, exist_ok=True)
    table = comparison(summaries)
    (dest / 'comparison.md').write_text(table, encoding='utf-8')
    with (dest / 'comparison.csv').open('w', newline='', encoding='utf-8-sig') as f:
        writer = csv.DictWriter(f, fieldnames=list(summaries[0]))
        writer.writeheader()
        writer.writerows(summaries)
    write_json(dest / 'validation.json', {'assignment_numeric_checks_passed': passed,
                                         'retraction_warning': any(s['nonzero_retractions'] for s in summaries)})
    print(table)
    print('数据检查：', 'PASS' if passed else 'FAIL', '；表格保存在', dest)
    if not passed:
        raise RuntimeError('结果未满足题目完成标准；失败结果已保留，不能当作合格实验')
    if any(s['nonzero_retractions'] for s in summaries):
        print('WARNING: 存在请求回退重算，请检查显存压力，谨慎解释性能。')


if __name__ == '__main__':
    entrypoint(main)
