## 1 GPU 与软件版本

| 项目 | target3 配置 |
|---|---|
| GPU | 4×NVIDIA GeForce RTX 3080 Ti，每卡 12 GB |
| 系统 | Ubuntu 22.04.5 |
| Python | 3.12.3 |
| SGLang / Ray | 0.5.14 / 2.56.0 |
| PyTorch / CUDA Toolkit | 2.11.0 cu130 / 13.0 |
| NVIDIA 驱动 | 595.71.05 |
| aiohttp / protobuf | 3.14.3 / 6.33.6 |
| 模型 | Qwen/Qwen3-0.6B |

四个 SGLang 后端分别使用 GPU 0–3、端口 31000–31003；统一 Serve 入口为 `http://127.0.0.1:8000/generate`。1 个 Ray head 提供 HTTP Proxy，4 个逻辑 worker 各运行 1 个 Replica，每个 Replica 固定转发到对应后端。

四个后端使用相同配置，参数位于 `src/target3/settings.py`。

| 参数 | 值 |
|---|---|
| dtype | bf16 |
| context length | 4096 |
| mem_fraction_static | 0.75 |
| max_running_requests | 128 |
| chunked_prefill_size | 2048 |
| max_prefill_tokens | 16384 |
| Decode CUDA Graph max batch size | 32 |
| attention backend | FlashInfer |
| stream_interval | 1 |
| random seed | 2026 |

## 2 安装方法

以下命令在四卡 Linux 服务器上执行，系统已安装 NVIDIA 驱动、CUDA Toolkit 13.0 和 Python 3.12。

进入解压后的目录，设置 CUDA 路径并检查 GPU 和 CUDA 版本：

```bash
cd HW3-052502222
export CUDA_HOME=/usr/local/cuda-13.0
export PATH="$CUDA_HOME/bin:$PATH"
export LD_LIBRARY_PATH="$CUDA_HOME/lib64${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
nvidia-smi
nvcc --version
```

创建并激活 Python 环境，安装实验依赖并检查依赖冲突：

```bash
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip -i https://pypi.tuna.tsinghua.edu.cn/simple
python -m pip install torch==2.11.0 torchaudio==2.11.0 \
  --index-url https://download.pytorch.org/whl/cu130
python -m pip install -r src/target3/requirements.txt \
  -i https://pypi.tuna.tsinghua.edu.cn/simple
python -m pip check
```

下载 Qwen3-0.6B 模型到本地模型目录：

```bash
export HF_ENDPOINT=https://hf-mirror.com
export HF_HUB_DISABLE_XET=1
python -c 'from huggingface_hub import snapshot_download; snapshot_download("Qwen/Qwen3-0.6B", revision="c1899de289a04d12100db370d81485cdf75e47ca", local_dir="models/Qwen3-0.6B", token=False)'
```

固定负载和回放脚本位于 `src/target3/workload/`，以下命令校验负载：

```bash
python src/target3/workload/validate_workload.py \
  src/target3/workload/mooncake_prefix_workload_v2_seed2026.jsonl
```

校验结果应包含 64 个前缀族、64 条预热和 2048 条测量请求。

## 3 启动与回放

打开三个服务器终端，每个终端进入同一个 `HW3-052502222` 根目录，执行以下命令激活 Python 环境、提高可打开文件数量上限并设置 CUDA 路径：

```bash
source .venv/bin/activate
ulimit -Sn 65535
export CUDA_HOME=/usr/local/cuda-13.0
export PATH="$CUDA_HOME/bin:$PATH"
export LD_LIBRARY_PATH="$CUDA_HOME/lib64${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
```

终端 1 启动四个后端，等待“四个后端均已就绪”：

```bash
python src/target3/start_backends.py
```

终端 2 启动 Ray 集群，等待“集群已就绪”：

```bash
python src/target3/start_cluster.py
```

保留前两个终端运行，在终端 3 依次回放各组：

```bash
python src/target3/run_round.py A_default/replay-1 p2c 5
python src/target3/run_round.py B_candidates/max-8/replay-1 p2c 8
python src/target3/run_round.py B_candidates/max-32/replay-1 p2c 32
python src/target3/run_round.py B_candidates/max-32/replay-2 p2c 32
python src/target3/run_round.py C_affinity/replay-1 consistent_hash 32
python src/target3/run_round.py C_affinity/replay-2 consistent_hash 32
python src/target3/run_round.py D_improved/replay-1 affinity_load 32 --threshold 0.75
python src/target3/run_round.py D_improved/replay-2 affinity_load 32 --threshold 0.75
```

每条命令自动重建 Serve、保存运行配置、清空四后端缓存，再完成预热和测量。客户端 max_in_flight 为 2048，timeout 为 300 秒。每轮应有 64 条预热和 2048 条测量成功，failed、incomplete 为 0。新实验使用 `replay-*` 目录，已有实验结果使用 `run-*`。

停止时在终端 3 执行以下命令，再依次在终端 2、终端 1 按 `Ctrl+C`：

```bash
python src/target3/deploy.py --stop
```

## 4 脚本用途

| 路径 | 用途 |
|---|---|
| `src/target3/settings.py` | 模型、GPU、端口和 SGLang 参数，节点状态校验 |
| `src/target3/start_backends.py` | 启动四个独立 SGLang 进程并检查就绪 |
| `src/target3/start_cluster.py` | 创建 1 head＋4 worker，并保存节点与后端绑定 |
| `src/target3/serve_app.py` | Replica 固定转发后端，透传 SSE，返回实际 Replica、Node 和 Backend 响应头 |
| `src/target3/deploy.py` | 部署 A/B/C/D 路由配置和四个 Replica |
| `src/target3/improved_router.py` | D 组路由策略实现 |
| `src/target3/run_round.py` | 串联部署、清缓存、预热和测量 |
| `src/target3/requirements.txt` | 服务依赖及版本 |
| `src/target3/workload/run_workload.py` | 流量发生器，生成完整 CSV/JSON |
| `src/target3/workload/validate_workload.py` | 校验固定负载 |
| `src/target3/workload/compare_runs.py` | 比较各配置的单轮及重复轮统计 |

## 5 结果目录与报告表格

报告表 1 的配置见各轮 `config.json`；表 2 每行对应下列目录中的 `summary.json`；`results/target3/comparison.csv` 为相同数据的汇总表。

| 报告行 | `results/target3/` 下目录 |
|---|---|
| A run-1 | `A_default/run-1/` |
| B8 run-1 | `B_candidates/max-8/run-1/` |
| B32 run-1、run-2 | `B_candidates/max-32/run-1/`、`run-2/` |
| C run-1、run-2 | `C_affinity/run-1/`、`run-2/` |
| D run-1、run-2 | `D_improved/run-1/`、`run-2/` |

每轮包含四个输出文件：

| 文件 | 内容 |
|---|---|
| `config.json` | 运行参数、模型、路由配置与负载摘要 |
| `warmups.csv` | 64 条预热记录 |
| `requests.csv` | 2048 条测量记录，含状态、token、计时与后端标识 |
| `summary.json` | 总体、分阶段、分热度及后端分布统计 |

以下命令读取各轮 `summary.json`，以 A 为基准比较各组指标，并将汇总结果保存到 `comparison-recomputed.json`：

```bash
python src/target3/workload/compare_runs.py \
  --baseline A \
  --run A=results/target3/A_default/run-1/summary.json \
  --run B8=results/target3/B_candidates/max-8/run-1/summary.json \
  --run B32=results/target3/B_candidates/max-32/run-1/summary.json \
  --run B32=results/target3/B_candidates/max-32/run-2/summary.json \
  --run C=results/target3/C_affinity/run-1/summary.json \
  --run C=results/target3/C_affinity/run-2/summary.json \
  --run D=results/target3/D_improved/run-1/summary.json \
  --run D=results/target3/D_improved/run-2/summary.json \
  --output comparison-recomputed.json
```
